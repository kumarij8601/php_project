<?php

require_once 'Field.php';

class RadioField extends Field
{
    private $options;

    public function __construct($name, $label, $options, $value = '')
    {
        parent::__construct($name, $label, $value);
        $this->options = $options;
    }

    public function render()
    {
        $html = "<label>{$this->label}</label><br>";
        foreach ($this->options as $option) {
            $checked = ($this->value == $option) ? 'checked' : '';
            $html .= "
                <input type='radio' name='{$this->name}' value='{$option}' {$checked}> {$option}<br>
            ";
        }
        return $html;
    }
}
?>