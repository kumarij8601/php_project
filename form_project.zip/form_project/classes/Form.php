<?php
// /classes/Form.php
require_once 'TextField.php';
require_once 'CheckboxField.php';
require_once 'RadioField.php';
require_once 'SelectField.php';

class Form
{
    private $fields = [];

    public function __construct($fieldConfigs)
    {
        foreach ($fieldConfigs as $config) {
            switch ($config['type']) {
                case 'text':
                    $this->fields[] = new TextField($config['name'], $config['label'], $config['value']);
                    break;
                case 'checkbox':
                    $this->fields[] = new CheckboxField($config['name'], $config['label'], $config['value']);
                    break;
                case 'radio':
                    $this->fields[] = new RadioField($config['name'], $config['label'], $config['options'], $config['value']);
                    break;
                case 'select':
                    $this->fields[] = new SelectField($config['name'], $config['label'], $config['options'], $config['value']);
                    break;
            }
        }
    }

    public function render()
    {
        $html = "<form method='POST'>";
        foreach ($this->fields as $field) {
            $html .= $field->render() . "<br>";
        }
        $html .= "<button type='submit'>Submit</button></form>";
        return $html;
    }
}
?>