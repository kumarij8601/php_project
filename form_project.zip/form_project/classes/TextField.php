<?php

require_once 'Field.php';

class TextField extends Field
{
    public function render()
    {
        return "
            <label for='{$this->name}'>{$this->label}</label>
            <input type='text' name='{$this->name}' id='{$this->name}' value='{$this->value}'>
        ";
    }
}
?>