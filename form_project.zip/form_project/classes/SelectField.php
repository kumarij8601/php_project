<?php

require_once 'Field.php';

class SelectField extends Field
{
    private $options;

    public function __construct($name, $label, $options, $value = '')
    {
        parent::__construct($name, $label, $value);
        $this->options = $options;
    }

    public function render()
    {
        $html = "<label for='{$this->name}'>{$this->label}</label><select name='{$this->name}' id='{$this->name}'>";
        foreach ($this->options as $option) {
            $selected = ($this->value == $option) ? 'selected' : '';
            $html .= "<option value='{$option}' {$selected}>{$option}</option>";
        }
        $html .= "</select>";
        return $html;
    }
}
?>