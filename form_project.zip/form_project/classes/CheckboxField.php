<?php

require_once 'Field.php';

class CheckboxField extends Field
{
    public function render()
    {
        $checked = $this->value ? 'checked' : '';
        return "
            <label for='{$this->name}'>{$this->label}</label>
            <input type='checkbox' name='{$this->name}' id='{$this->name}' {$checked}>
        ";
    }
}
?>