<?php

require_once 'classes/Form.php';

$conn = new mysqli('localhost', 'root', '', 'form_db');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $field_name => $field_value) {
        $stmt = $conn->prepare("INSERT INTO form_data (field_name, field_value) VALUES (?, ?)");
        $stmt->bind_param('ss', $field_name, $field_value);
        $stmt->execute();
        $stmt->close();
    }
    echo "Form submitted successfully!";
}

$fieldConfigs = [
    ['type' => 'text', 'name' => 'username', 'label' => 'Username', 'value' => ''],
    ['type' => 'checkbox', 'name' => 'agree_terms', 'label' => 'Agree to Terms', 'value' => ''],
    ['type' => 'radio', 'name' => 'gender', 'label' => 'Gender', 'options' => ['Male', 'Female'], 'value' => ''],
    ['type' => 'select', 'name' => 'country', 'label' => 'Country', 'options' => ['USA', 'Canada', 'Mexico'], 'value' => '']
];

$form = new Form($fieldConfigs);
echo $form->render();
?>