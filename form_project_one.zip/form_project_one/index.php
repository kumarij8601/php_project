
<?php session_start();
include('dbcon.php');

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Document</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
     #max_1
        {
            height:390px;
            width:50%;
            margin:auto;
       
            padding-left:15px;
            padding-top:5px;
        }
  </style>
</head>
<body>


<div class="container mt-3" id="max_1">

<div class="card-header">

<h3>PHP CRUD

<a href="register.php" class="btn btn-primary float-end">Add Student</a>

</h3>

</div>
  <h2></h2>
  <?php if(isset( $_SESSION['message'])):?>
    <h5 class="alert  alert-success"><?= $_SESSION['message'];?></h5>
    <?php unset($_SESSION['message']); endif;?>          
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Address</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php

$query = "SELECT * FROM user";

$statement = $conn->prepare($query);

$statement->execute();

$result = $statement->fetchAll(); 
if ($result)

{

    foreach($result as $row)
    {
        ?>

<tr>
        <td><?= $row['id'];?></td>
        <td><?= $row['name'];?></td>
        <td><?= $row['number'];?></td>
        <td><?= $row['email'];?></td>
        <td><?= $row['address'];?></td>
        
        <td>
            
        <a href="user_edit.php?id=<?= $row['id'];?>" class="btn btn-primary">update</a>
        
    
    </td>
    <td><form action="code.php" method="post">
            <button type="submit" name="delete_data" class="btn btn-danger" value="<?= $row['id'];?>">Delete</button>
        </form></td>
      </tr>
   
        <?php

    }
}


else

{
?>

<tr>
    <td colspan="5">No Record Data</td>
</tr>
<?php
}

?>
     
      
    </tbody>
  </table>
</div>

</body>
</html>
<!-- <!DOCTYPE html>
<html>
<head>
<style> 
input[type=text] {
  width: 20%;
  padding: 6px 20px;
  margin: 4px 0;
  box-sizing: border-box;
}
</style>
</head>
<body>


<center>
    
<h2>Padded input fields</h2>
<?php if(isset( $_SESSION['message'])):?>
    <h5 class="alert  alert-success"><?= $_SESSION['message'];?></h5>
    <?php endif;?>
</center>

</body>
</html> -->