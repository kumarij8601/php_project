
<?php
include('dbcon.php');

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Document</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
     #max_1
        {
            height:390px;
            width:40%;
            margin:auto;
       
            padding-left:15px;
            padding-top:5px;
        }
  </style>
</head>
<body>

<div class="container mt-3" id="max">
  
  <div class="card">
  <div class="card-header">

<h3>PHP CRUD

<a href="index.php" class="btn btn-primary float-end">Back</a>

</h3>

</div>
    <div class="card-body " id="max">
    

    <?php if(isset($_GET['id']))
    {
        $user_id =$_GET['id'];
        $query = "SELECT * FROM user WHERE id=:user_id LIMIT 1";
        $statement =$conn->prepare($query);
        $data=[
           ':user_id'=>$user_id
        ];
       $statement->execute($data);

       $result= $statement->fetch(PDO::FETCH_OBJ);
    }

?>
    <form action="code.php" method="post">
        <input type="hidden" name="user_id" value="<?= $result->id?>">
    <div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="name" placeholder="Enter Name" value="<?= $result->name?>" name="name">
  <label for="name">Name</label>
</div>
    
         <div class="form-floating mb-3 mt-3">
  <input type="email" class="form-control" id="email" placeholder="Enter email" value="<?= $result->email?>" name="email">
  <label for="email">Email</label>
</div>
<div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="number" placeholder="Enter Phone Number" value="<?= $result->number?>" name="number">
  <label for="name">Phone Number</label>
</div>
<div class="form-floating">
  <textarea class="form-control" id="Address" name="address" placeholder="Enter your Address"><?= $result->address?></textarea>
  <label for="comment">Address</label>
</div>
        
         <div class="text-center pt-5">
         <input type="submit" name="update_data" value="update" class="btn btn-primary" > 
         </div>
         <br>
         <br>
        
        </form></div> 
    
  </div>
</div>

</body>
</html>
