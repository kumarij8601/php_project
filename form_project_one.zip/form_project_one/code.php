<?php
session_start();
include('dbcon.php');

///insert Data
if(isset($_POST["save_data"])){
    $name=$_POST["name"];
    // echo $name;
    // exit;
    $email=$_POST["email"];
    $number=$_POST["number"];
    $address=$_POST["address"];



    $query="INSERT INTO user(name,email,number,address) VALUES(:name, :email, :number, :address)";
    $query_run =$conn->prepare($query);

    $data=[
        ':name'=>$name,
        ':email'=>$email,
        ':number'=>$number,
        ':address'=>$address,
    ];
   $query_execute= $query_run->execute($data);
   if($query_execute)
   {

    $_SESSION['message'] = "Inserted Successfully";
    header('location:index.php');
    exit(0);

   }
   else{

    $_SESSION['message'] = " Not  Inserted  Data";
    header('location:register.php');
    exit(0);
   }



}
////  Update data
if(isset($_POST["update_data"])){
    $name=$_POST["name"];
    $email=$_POST["email"];
    $number=$_POST["number"];
    $address=$_POST["address"];
    $user_id = $_POST["user_id"];
    try{

        $query ="UPDATE user SET name=:name, email=:email,number=:number,address=:address WHERE id=:user_id LIMIT 1";
        $statement =$conn->prepare($query);
        $data=[
           ':name'=>$name,
        ':email'=>$email,
        ':number'=>$number,
        ':address'=>$address,
        ':user_id' => $user_id

        ];
     $query_execute=  $statement->execute($data);

     if($query_execute)
   {

    $_SESSION['message'] = "Updated Successfully";
    header('location:index.php');
    exit(0);

   }
   else{

    $_SESSION['message'] = " Not  Update  Data";
    header('location:user_edit.php');
    exit(0);
   }
    }

    catch(PDOException $e){

        echo $e->getMessage();

    }

}


// Deleted Data code
if(isset($_POST["delete_data"])){

    $user_id=$_POST['delete_data'];
    try{

        $query ="DELETE FROM user WHERE id=:user_id";
        $statement= $conn->prepare($query);
        $data=[':user_id'=>$user_id];
      $query_execute = $statement->execute($data);

      if($query_execute)
      {
   
       $_SESSION['message'] = "Deleted Successfully";
       header('location:index.php');
       exit(0);
   
      }
      else{
   
       $_SESSION['message'] = " Not  Deleted Data";
       header('location:index.php');
       exit(0);
      }

    }
    catch(PDOException $e)
    {

        echo $e->getMessage();
    }
}


?>